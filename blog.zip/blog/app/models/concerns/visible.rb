module Visible
  def archived?
    status == 'archived'
  end
end
